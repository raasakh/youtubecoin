ssh -i "VPS2.pem" ubuntu@ec2-35-166-148-179.us-west-2.compute.amazonaws.com

start_mining Ytubey58zAibw215yRWsEdE6XC3PuyuA8SVenT2V9aEAhqPJonH4D3H8hEzRPmtLv7S3HuQ2P3ZE7XPyZ9coayFtWKkK9iiqrM23B [threads=1]﻿

start_mining Ytubey4wVA14WURoYkcb4mBGH2E8a5BmhWqYF2FL1xa4G4xv2RXSFj24Rodc3wycgm2roHGjydcp4X5xFqHBusGKW5E6HQWMucz1m [threads=1]﻿

start_mining Ytubey5WciZgeek3FQB8trPzHtNCByRKXdQ52BVzzddF3G4YiYisdwDfnYAgGJvLmvXBGZTu2LUu9c46mRvQaGv1PiB4HrmerX62N [threads=1]﻿

print_cn 


cd youtube/build/release/src
./simplewallet –generate-new-wallet=ytb_wallet.bin
./simplewallet –wallet-file=ytb_wallet.bin

Терминал команда mc

Прошу вас рассмотреть добавление криптовалюты YouTubeCoin [ YTB] на биржу Сryptopia
      YouTubeCoin  https://www.youtube.com/playlist?list=PLbmk28cmW3C4xi3IehVQmqrejBQ5ejV2B и создал серию видео уроков по созданию монеты с нуля до полного функционала... 
          Сайт решил разместить на бесплатной платформе БлогСпот http://youtubecoin.blogspot.ru/ для быстрого оповещения и индексации в поисковиках.
          Исходники https://sourceforge.net/projects/youtubecoin/files/ 
Github https://github.com/raasakh/youtubecoin

I ask you to consider addition of cryptocurrency of YouTubeCoin [ YTB ] on the Cryptopia exchange
      The coin was called by YouTubeCoin https://www.youtube.com/playlist? list=PLbmk28cmW3C4xi3IehVQmqrejBQ5ejV2B has also created a series of video of lessons of creation of a coin from scratch to full functionality... 
          The website has decided to place on a free platform of Blogspot http://youtubecoin.blogspot.ru/ for the bystry notification and indexation in search engines.
          Source codes of https://sourceforge.net/projects/youtubecoin/files/ 
Github https://github.com/raasakh/youtubecoin

youtube v0.0.1.1()
Commands: 
  exit            Shutdown the daemon
  help            Show this help
  hide_hr         Stop showing hash rate
  print_bc        Print blockchain info in a given blocks range, print_bc <begin_height> [<end_height>]
  print_block     Print block, print_block <block_hash> | <block_height>
  print_cn        Print connections
  print_pl        Print peer list
  print_pool      Print transaction pool (long format)
  print_pool_sh   Print transaction pool (short format)
  print_tx        Print transaction, print_tx <transaction_hash>
  set_log         set_log <level> - Change current log level, <level> is a number 0-4
  show_hr         Start showing hash rate
  start_mining    Start mining for specified address, start_mining <addr> [threads=1]
  stop_mining     Stop mining

  {10101, "cf41cbbc80ccdd2b590b95766b18c9443b9403bafec13c69c485d2d985332f94" },
  {39663, "ce4884d32d25317c02bd44b8a758244531bbac6848579396180c5b4e2c15b77e" },
  {46674, "8c05b203e4151d0b43250fab1894de73c32baf027b3de27a61038a8dc4938968" }


print_tx cf41cbbc80ccdd2b590b95766b18c9443b9403bafec13c69c485d2d985332f94
 
print_tx ce4884d32d25317c02bd44b8a758244531bbac6848579396180c5b4e2c15b77e ЭТО Последний хешь Блок 39663 Перед Атакой

print_tx 8c05b203e4151d0b43250fab1894de73c32baf027b3de27a61038a8dc4938968



